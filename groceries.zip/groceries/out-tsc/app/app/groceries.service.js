import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { GroceryItem } from "./grocery/grocery.item";
import { map } from "rxjs/operators";
let GroceriesService = class GroceriesService {
    constructor(http) {
        this.http = http;
        this.items = [];
        // base url for accessing the groceries api
        this.base = "http://localhost:8080/api/groceries";
    }
    // TODO remember to reference this code when creating the autocomplete feature for the hophead app
    // https://stackblitz.com/github/codecraft-tv/angular-course/tree/current/11.HTTP/4.http-with-observables/code
    getItems() {
        return this.http.get(this.base).pipe(map(res => {
            // @ts-ignore
            return res.results.map(item => {
                let groceryItem = new GroceryItem();
                groceryItem.id = item._id;
                groceryItem.name = item.name;
                groceryItem.price = item.price;
                groceryItem.totalCost = item.totalCost;
                return groceryItem;
            });
        }));
    }
    removeItem(index) {
        this.items.splice(index, 1);
    }
    addItem(item) {
        this.items.push(item);
    }
    editItem(item, index) {
        this.items[index] = item;
    }
};
GroceriesService = __decorate([
    Injectable({
        providedIn: 'root'
    })
], GroceriesService);
export { GroceriesService };
//# sourceMappingURL=groceries.service.js.map