import { __decorate } from "tslib";
import { Component } from '@angular/core';
let TabsPage = class TabsPage {
    constructor() { }
};
TabsPage = __decorate([
    Component({
        selector: 'app-tabs',
        templateUrl: 'tabs.page.html',
        styleUrls: ['tabs.page.scss']
    })
], TabsPage);
export { TabsPage };
//# sourceMappingURL=tabs.page.js.map