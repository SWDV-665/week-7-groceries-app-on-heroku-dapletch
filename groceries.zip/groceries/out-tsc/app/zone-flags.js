/**
 * Prevents Angular change detection from
 * running with certain Web Component callbacks
 */
window.__Zone_disable_customElements = true;
//# sourceMappingURL=zone-flags.js.map