import { TestBed } from '@angular/core/testing';
import { InputDialogService } from './input-dialog.service';
describe('InputDialogService', () => {
    let service;
    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(InputDialogService);
    });
    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
//# sourceMappingURL=input-dialog.service.spec.js.map