import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {GroceryItem} from "./grocery/grocery.item";
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class GroceriesService {

  // base url for accessing the groceries api
  private base: string = "https://stp-groceries-api.herokuapp.com/api/groceries";

  constructor(private http: HttpClient) {
  }

  // TODO remember to reference this code when creating the autocomplete feature for the hophead app
  // https://stackblitz.com/github/codecraft-tv/angular-course/tree/current/11.HTTP/4.http-with-observables/code
  getItems() {
    return this.http.get(this.base).pipe(
      map(res => {
        console.log("res: " + res);
        // @ts-ignore
        return res.map(item => {
          let groceryItem = new GroceryItem();
          groceryItem.id = item._id;
          groceryItem.name = item.name;
          groceryItem.quantity = item.quantity;
          groceryItem.price = item.price;
          groceryItem.totalCost = item.totalCost;
          return groceryItem;
        });
      })
    );
  }

  removeItem(id): void {
    this.http.delete(`${this.base}/${id}`).subscribe(res => {
      console.log("Delete response: " + res);
    }, err => {
      console.log("Delete error: " + err);
    });
  }

  // referenced this item here: https://www.techiediaries.com/ionic-http-post/
  addItem(groceryItem: GroceryItem): void {
    if (groceryItem != null || groceryItem !== undefined) {

      let data = {
        name: groceryItem.name,
        quantity: groceryItem.quantity,
        price: groceryItem.price
      }

      this.http.post(this.base, data).subscribe(res => {
        console.log("Create response: " + res);
      }, err => {
        console.log("Create error: " + err);
      });
    } else {
      console.error("Invalid groceryItem...");
    }
  }

  editItem(groceryItem: GroceryItem, id) {
    if (groceryItem != null || groceryItem !== undefined) {

      let data = {
        name: groceryItem.name,
        quantity: groceryItem.quantity,
        price: groceryItem.price
      }
      this.http.put(`${this.base}/${id}`, data).subscribe(res => {
        console.log("Delete response: " + res);
      }, err => {
        console.log("Delete error: " + err);
      });
    } else {
      console.error("Invalid groceryItem...");
    }
  }
}
