import {Injectable} from '@angular/core';
import {AlertController} from '@ionic/angular';
import {GroceriesService} from "./groceries.service";
import {GroceryItem} from "./grocery/grocery.item";

@Injectable({
  providedIn: 'root'
})
export class InputDialogService {

  constructor(public alertController: AlertController, public dataService: GroceriesService) {
    console.log('Hello InputDialogService Provider');
  }

  async showPrompt(item?, id?) {
    const prompt = await this.alertController.create({
      header: item ? 'Edit Item' : 'Add Item',
      message: item ? "Please edit item..." : "Please enter item...",
      inputs: [
        {
          name: 'name',
          placeholder: 'Name',
          value: item ? item.name : null
        },
        {
          name: 'quantity',
          placeholder: 'Quantity',
          value: item ? item.quantity : null
        },
        {
          name: 'price',
          placeholder: 'Price',
          value: item ? item.price : null
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: item => {
            console.log('Saved clicked', item);
            if (id !== undefined) {
              // declare new instance of GroceryItem to add,
              // had to change the way it was being constructed due to using an API
              let groceryItem = new GroceryItem();
              groceryItem.id = item.id;
              groceryItem.name = item.name;
              groceryItem.quantity = item.quantity;
              groceryItem.price = item.price;
              // now edit the item
              this.dataService.editItem(
                groceryItem,
                id
              );
            }
            else {
              let groceryItem = new GroceryItem();
              groceryItem.name = item.name;
              groceryItem.quantity = item.quantity;
              groceryItem.price = item.price;
              this.dataService.addItem(groceryItem);
            }

          }
        }
      ]
    });
    prompt.present();
  }
}
