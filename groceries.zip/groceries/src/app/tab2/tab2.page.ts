import {Component, OnInit} from '@angular/core';
import {NavController, AlertController, ToastController} from '@ionic/angular';
import {GroceryItem} from "../grocery/grocery.item";
import {GroceriesService} from "../groceries.service";
import {InputDialogService} from "../input-dialog.service";
import {SocialSharing} from '@ionic-native/social-sharing/ngx';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit {

  public groceryItems : GroceryItem[]

  constructor(public toastCtrl: ToastController,
              public alertController: AlertController,
              public navCtrl: NavController,
              public dataService: GroceriesService,
              public inputDialogService: InputDialogService,
              public socialSharing: SocialSharing) {

  }

  ngOnInit(): void {
    this.loadItems();
  }

  loadItems(): void {
    this.dataService.getItems().subscribe(items =>
      (this.groceryItems = items)
    );
  }

  async removeItem(item, id) {
    console.log("Removing Item - ", item, id);
    const toast = await this.toastCtrl.create({
      message: 'Removing Item - ' + id + " ...",
      duration: 3000
    });
    toast.present();

    this.dataService.removeItem(id);
    this.loadItems();
  }

  async shareItem(item, id) {
    console.log("Sharing Item - ", item, id);
    const toast = await this.toastCtrl.create({
      message: 'Sharing Item - ' + id + " ...",
      duration: 3000
    });

    toast.present();

    let message = "Grocery Item - Name: " + item.name + " - Quantity: " + item.quantity;
    let subject = "Shared via Groceries app";

    this.socialSharing.share(message, subject).then(() => {
      // Sharing via email is possible
      console.log("Shared successfully!");
    }).catch((error) => {
      console.error("Error while sharing ", error);
    });

  }

  async editItem(item, id) {
    console.log("Edit Item - ", item, id);
    const toast = await this.toastCtrl.create({
      message: 'Editing Item - ' + id + " ...",
      duration: 3000
    });
    toast.present();
    this.inputDialogService.showPrompt(item, id);
    // refresh list of items, again..
    this.loadItems();
  }

  addItem() {
    console.log("Adding Item");
    this.inputDialogService.showPrompt();
    // calling the loadItems method to instantiate a refresh
    this.loadItems();
  }
}
